<h1 align="center">THIS REPOSITORY IS A PUBLIC</h1>

A.I. Trained Model Which is Used for this Project, reference https://huggingface.co/black-forest-labs/FLUX.1-schnell

<h1 align="center">
<br>
<img src="./assets/IN Logo.png">
<br>
A.I. Image Generator
</h1>

# Description

A.I. Image Generator is created by using HTML, CSS, JavaScript. Used to generate images for an A.I. trained Model.

# Features

Prompt Image Generator. Can able to use to Generate Images which are Lower the works of Image Editing and Easy to generate which are not avaliable online.

# Binary Samples

Idle Satae of The Website

<p align="center"> <img src="./assets/Screenshot 2024-08-18 143209.png">

Generating State of Images

<p align="center"> <img src="./assets/Screenshot 2024-08-18 143616.png">

Image Which are complete Generating

<p align="center"> <img src="./assets/Screenshot 2024-08-18 144457.png">

# Sample Images of My Website

Realistic Cave

<p align="center"> <img src="./assets/Cave.jpg">

Flying UFO

<p align="center"> <img src="./assets/UFO.jpg">

BMW Car

<p align="center"> <img src="./assets/BMW.jpg">

Avengers

<p align="center"> <img src="./assets/Avengers.jpg">

# Note

<h1 align="center">
Generate Your API Key From Hugging Face
</h1>
